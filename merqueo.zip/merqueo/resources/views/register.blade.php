@extends('layouts.master')
 
@section('content')
 
    <h2>Register Form</h2>
    
    <div id="cont_form_errors" style="display: none; color: red;"></div>
    <div id="cont_form_success" style="display: none; color: black;background-color: green"></div>
    <form id="form-register" method="POST" data-url="{{url('register')}}" action="javascript:void(0);">
        {{ csrf_field() }}
        
        <div class="form-group">
            <label for="name">Document Type:</label>
                <select class="form-control" id="documentType" name="documentType">
                    <option value="" selected="true"> Choose </option>
                <option value="CC" >Cédula  ciudadania</option>
                <option value="TI">Tarjeta identidad</option>
                <option value="CE">Cédula Extrangería</option>
                <option value="PP">Pasaporte</option>
            </select>
        </div>
        
        <div class="form-group">
            <label for="name">Identification Number:</label>
            <input type="text" class="form-control" id="identification" name="identification" >
        </div>
        
        <div class="form-group">
            <label for="name">Full Name:</label>
            <input type="text" class="form-control" id="fullName" name="fullName" >
        </div>
 
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" class="form-control" id="email" name="email" >
        </div>
 
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" class="form-control" id="password" name="password" >
        </div>
        
        <div class="form-group">
            <label for="password">Confirm Password:</label>
            <input type="password" class="form-control" id="confirmPassword" name="confirmPassword" >
        </div>
 
        <div class="form-group">
            <button id="btn-submit" style="cursor:pointer" type="submit" class="btn btn-primary">Submit</button>
        </div>
        
    </form>
 
@endsection
