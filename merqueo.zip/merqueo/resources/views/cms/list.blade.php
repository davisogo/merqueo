@extends('layouts.master')

@section('content')
 @if( auth()->check() )
<div class="container">
    <h2>Results table</h2>
    <table class="table">
        <thead>
            <tr>
                <th>User Id</th>
                <th>Full Name</th>
                <th>String - Text File</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($registersTxt as $register)
            <tr>
                <td>{{ $register->id }}</td>
                <td>{{ $register->fullName }}</td>
                <td>{{ $register->text }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endif
@endsection