@extends('layouts.master')
 
@section('content')
 
    <h2>Login Form</h2>
    
    @if (count($errors) > 0)
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
            </ul>
        </div>
    @endif
    
    <div id="cont_form_errors" style="display: none; color: red;"></div>
    <div id="cont_form_success" style="display: none; color: black;background-color: green"></div>
    <form id="form-login" method="POST"  action="{{url('login')}}">
        {{ csrf_field() }}
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" class="form-control" id="email" name="email" >
        </div>
 
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" class="form-control" id="password" name="password" >
        </div>
 
        <div class="form-group">
            <button id="btn-login" style="cursor:pointer" type="submit" class="btn btn-primary">Login</button>
        </div>
        
    </form>
 
@endsection
