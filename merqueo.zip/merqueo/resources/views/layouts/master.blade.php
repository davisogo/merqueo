<!DOCTYPE html>
<html>
    <head>
        <title>Merqueo - @yield('title')</title>
        <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script> var main = {};</script>
        <script src="{{asset('js/main.js')}}" type="text/javascript"></script>
    </head>
    <body>
        @if( auth()->check() )
            <a class="nav-link" href="/merqueo/public/cms/importfile">Import File .txt</a> |
            <a class="nav-link" href="/merqueo/public/cms/list">Show Data</a>
            <div style="text-align: right;">
                Welcome,  {{ auth()->user()->fullName }}
            </div>
             @else
             <a class="nav-link" href="/merqueo/public/login">Log In</a>
             <a class="nav-link" href="/merqueo/public/register">Register</a>
             @endif
        @yield('content')
    </body>
</html>