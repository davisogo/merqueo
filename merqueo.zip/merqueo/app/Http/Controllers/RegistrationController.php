<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator;

class RegistrationController extends Controller {

    /**
     * Display a listing of the myform.
     *
     * @return \Illuminate\Http\Response
     */
    public function create() {
        return view('register');
    }

    public function store(Request $request) {
        $validator = Validator::make($request->all(), [
                    'documentType' => 'required',
                    'identification' => 'required',
                    'fullName' => 'required',
                    'email' => 'required|email',
                    'password' => 'required',
                    'confirmPassword' => 'required'
        ]);


        if ($validator->passes()) {
            $user = \App\Register::where('email', $request->email)->first();
            if (!is_null($user)) {
                return response()->json(['error' => array('Email already exist.')]);
            }

            \App\Register::create([
                        'documentType' => $request->documentType,
                        'identification' => $request->identification,
                        'fullName' => $request->fullName,
                        'email' => $request->email,
                        'password' => bcrypt($request->password),
            ]);
            return response()->json(['success' => 'Added new records.']);
        }

        return response()->json(['error' => $validator->errors()->all()]);
    }

}
