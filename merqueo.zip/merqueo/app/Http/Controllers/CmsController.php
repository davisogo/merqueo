<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use File;
use DB;

/**
 * Description of CmsController
 *
 * @author mac
 */
class CmsController extends Controller {

    public function index() {
        return view('cms.index');
    }

    public function importfile() {
        return view('cms.importfile');
    }

    public function showlist() {
        $registersTxt = DB::table('users')
            ->Join('files', 'users.id', '=', 'files.user_id')
            ->get();
        return view('cms.list', ['registersTxt' => $registersTxt]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function importtxt(Request $request) {
        if ($request->file('importedfile')) {
            $file = File::get($request->importedfile);
            $array = explode(',', $file);
            $caps_match = array();
            
            for ($i = 0; $i < count($array); $i++) {
                preg_match_all("/[A-Z]/", $array[$i], $caps_match); 
                $caps_count = count($caps_match [0]); 
                $dataImported[$caps_count]= implode("", $caps_match [0]);
            }
            
            $maxlen = max(array_map('strlen', $dataImported));
            \App\Import::create([
                        'user_id' => auth()->user()->id,
                        'text' => $dataImported[$maxlen]
            ]);
        }
        return back()->withErrors([ 'message' => 'File uploaded sucessfull. ']);
    }

}
