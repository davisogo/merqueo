<?php $__env->startSection('content'); ?>
 <?php if( auth()->check() ): ?>
<div class="container">
    <h2>Results table</h2>
    <table class="table">
        <thead>
            <tr>
                <th>User Id</th>
                <th>Full Name</th>
                <th>String - Text File</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $registersTxt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $register): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($register->id); ?></td>
                <td><?php echo e($register->fullName); ?></td>
                <td><?php echo e($register->text); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>