/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

jQuery(function ($) {
    var $contErrors = $("div#cont_form_errors");
    var $contFormSuccess = $("div#cont_form_success");

    // initialize la JS funcionality
    var init = function () {
        var $btnSubmit = $("button#btn-submit");
        $btnSubmit.off().on("click", function (e) {
            e.preventDefault();

            var $form = $("form#form-register");
            var _isValid = _validateForm($form);
            if ($contFormSuccess.is(':visible')) {
                $contFormSuccess.html("").fadeOut("fast");
            }

            if (!_isValid) {
                $contErrors.animate({"margin-top": "20px"}).fadeIn('slow');
            } else {
                _submitForm($form, function (_result) {
                    console.log("_result", _result);
                    if ('error' in _result) {
                        $contErrors.html(_result.error[0]).animate({"margin-top": "20px"}, function () {
                            $(this).fadeIn('slow');
                        });
                    } else {
                        _clearForm($form, function () {
                            $contFormSuccess.html(_result.success).animate({"margin-top": "20px"}).fadeIn('slow');
                        });
                    }
                });
            }
        });
    };

    var _clearForm = function ($form, _callback) {
        $('input,select', $form).each(function () {
            $(this).val("");
        })

        _callback.call(this);
    };

    // Allow to validate form
    var _validateForm = function ($form) {
        if ($.trim($("select#documentType", $form).val()).length < 1) {
            $contErrors.html("Document type is mandatory");
            return  false;
        }

        if ($.trim($("input#identification", $form).val()).length < 1) {
            $contErrors.html("Identification is mandatory");
            return  false;
        }

        if ($.trim($("input#fullName", $form).val()).length < 1) {
            $contErrors.html("Full name is mandatory");
            return  false;
        }

        var email = $.trim($("input#email", $form).val());
        if (email.length < 1) {
            $contErrors.html("Email is mandatory");
            return  false;
        }

        if (!_isValidEmail(email)) {
            $contErrors.html("Email is not valid");
            return  false;
        }

        var pass1 = $.trim($("input#password", $form).val());
        if (pass1.length < 1) {
            $contErrors.html("Password is mandatory");
            return  false;
        }

        var pass2 = $.trim($("input#confirmPassword", $form).val());
        if (pass2.length < 1) {
            $contErrors.html("Confirm Password is mandatory");
            return  false;
        }

        if (pass1 !== pass2) {
            $contErrors.html("Password are not equals");
            return  false;
        }

        $contErrors.html("").fadeOut("fast");
        return true;
    };

    // Allow submit form to controller for be processed.
    var _submitForm = function ($form, _callback) {
        $.ajax({
            type: "POST",
            url: $form.attr("data-url"),
            data: $form.serialize(),
            success: function (msg) {
                _callback.call(this, msg);
            }
        });
    };

    // regex email
    var _isValidEmail = function (email) {
        var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        return regex.test(email);
    };

    main.merqueo = {
        init: init()
    };
});
